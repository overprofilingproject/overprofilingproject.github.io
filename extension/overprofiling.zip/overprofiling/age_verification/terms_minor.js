document.getElementById("submit_button_minor").onclick = function () {
  localStorage.setItem("age_consent","minor")
  chrome.runtime.sendMessage({type: 'age_consent', message:"minor" });

};
