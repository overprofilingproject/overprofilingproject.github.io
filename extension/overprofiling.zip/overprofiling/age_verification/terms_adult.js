document.getElementById("submit_button_adult").onclick = function () {
  localStorage.setItem("age_consent","adult")
  chrome.runtime.sendMessage({type: 'age_consent', message:"adult" });

};
