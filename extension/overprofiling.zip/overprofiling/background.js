/*Variables*/
var tabsArray = [];
var webRequestsMap = [];
var oldTabsArray = [];
var filter = {urls: ["<all_urls>"]};
//#####EXTRA INFO//////////
var filter_webs_visited = {urls: ["http://*/*","https://*/*"]};
var CURRENT_TAB_URL=""
var tab_ids_urls=[]
const tabStorage = {};
var USER_ID_VALUE=undefined;
CATEGORIES_BACKGROUND_TIMER_FB=1200000
CATEGORIES_BACKGROUND_TIMER_GOOGLE=1200000
AGREE_VALUE="no_result"
URL_DB="https://verea.networks.imdea.org:3000"
LIST_GENDER=["Mujer","Frau","Donna","Dona","Femme","Female","Hombre","Homme","Home","Uomo","Männlich","Male"]
REX_AGE=/( – )|([0-9]{2}–[0-9]{2} )|([0-9]{2}-[0-9]{2} )|(\+[0-9]{2} )/g
ERROR_lOGGING_FB_GENERAL=false
///-Conditions-//   chrome.tabs.remove(tab.id);
chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        //chrome.tabs.create({'url': 'survey/terms.html', active: true })
        chrome.tabs.create({'url': 'age_verification/terms_age_verification.html', active: true })
    }
});

/*******FB******/
/* This method allows parsing the preferences */
// This and the following method include the preferences inside the localStorage of the
/* Function for getting the preferences assigned to the user */
//This method works together with the previous one, the one below runs before getting the preference categories
//and the one above gets each particular preference and stores it under 'user_preferences' in localStorage
function getUserPreferences(){
  try{
    var xmlhttp = new XMLHttpRequest();
    var url_request = "https://m.facebook.com/ads/preferences/categories/";
    xmlhttp.open("GET",url_request, true);
    xmlhttp.onreadystatechange = function (e) {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && (!xmlhttp.responseURL.startsWith("https://m.facebook.com/login.php"))){
            var response = xmlhttp.responseText;
            var parser = new DOMParser();
            var htmlDoc = parser.parseFromString(response, 'text/html');
            let div = htmlDoc.querySelectorAll('[data-nt="NT:DECOR"]')
            var elements = [];
            for (index_div=0;index_div<div.length;index_div++){
              var category_fb=div[index_div].textContent
              try{
                splitter=category_fb.split(/Remove/g)

                if(splitter.length>1){
                  var category_final =splitter[0]
                  var preferences = new Object();
                  category_final=category_final.replace(",",":")
                  preferences.fbid = "no_result";
                  preferences.name = category_final;
                  preferences.topic = category_final;
                  preferences.id =index_div;
                  preferences.description = "no_result";
                  elements.push((preferences));
                }
              }catch(e){;}
            }
            //
            var obj = {};
            for ( var i=0, len=elements.length; i < len; i++ )
                obj[elements[i]['id']] = elements[i];
            elements = new Array();
            for ( var key in obj )
                elements.push(obj[key]);
            localStorage.setItem("user_preferences",JSON.stringify(elements));
        }
    };
    xmlhttp.send(null);
}catch(e){;}//First try, general one
}
//Survey
function getUserPreferences_survey(){
  FIRST_CHECK=true
  ERROR_NOT_LOGGING=false
  try{
    var xmlhttp = new XMLHttpRequest();
    var url_request = "https://m.facebook.com/ads/preferences/categories/";
    xmlhttp.open("GET",url_request, true);
    xmlhttp.onreadystatechange = function (e) {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && (!xmlhttp.responseURL.startsWith("https://m.facebook.com/login.php"))){
            var response = xmlhttp.responseText;
            var parser = new DOMParser();
            var htmlDoc = parser.parseFromString(response, 'text/html');
            let div = htmlDoc.querySelectorAll('[data-nt="NT:DECOR"]')
            var elements = [];
            for (index_div=0;index_div<div.length;index_div++){
              var category_fb=div[index_div].textContent
              try{
                splitter=category_fb.split(/Remove/g)

                if(splitter.length>1){
                  ERROR_lOGGING_FB_GENERAL=false
                  var category_final =splitter[0]
                  var preferences = new Object();
                  category_final=category_final.replace(",",":")
                  preferences.fbid = "no_result";
                  preferences.name = category_final;
                  preferences.topic = category_final;
                  preferences.id =index_div;
                  preferences.description = "no_result";
                  elements.push((preferences));
                }
              }catch(e){;}
            }
            //
            var obj = {};
            for ( var i=0, len=elements.length; i < len; i++ )
                obj[elements[i]['id']] = elements[i];
            //
            elements = new Array();
            for ( var key in obj )
                elements.push(obj[key]);
            localStorage.setItem("user_preferences",JSON.stringify(elements));
            ///
            ERROR_NOT_LOGGING=false
        }
        else if(xmlhttp.readyState === 4){
          ERROR_NOT_LOGGING=true
          ERROR_lOGGING_FB_GENERAL=true
        }
    };
    xmlhttp.send(null);
}catch(e){;}//First try, general one
}
////ADDED PELAYO FOR survey
function get_categories_for_survey(){
  FB_FIRST_CALL=true
  FB_ERROR=false
  GOOGLE_FIRST_CALL=false
  GOOGLE_ERROR=false
  try{
    var url_request_GOOGLE = "https://adssettings.google.com/authenticated";
    var xmlhttp_GOOGLE = new XMLHttpRequest();
    xmlhttp_GOOGLE.open("GET",url_request_GOOGLE, true);
    xmlhttp_GOOGLE.onreadystatechange = function (e) {
      if (xmlhttp_GOOGLE.readyState === 4 && xmlhttp_GOOGLE.status === 200 && (xmlhttp_GOOGLE.responseURL.startsWith("https://adssettings.google.com/authenticated") )){
        var response_GOOGLE = xmlhttp_GOOGLE.responseText;
        var parser = new DOMParser();
        var htmlDoc = parser.parseFromString(response_GOOGLE, 'text/html');
        let div = htmlDoc.querySelector("#yDmH0d > c-wiz > c-wiz > div > c-wiz:nth-child(4) > div")
        let lis = div.getElementsByTagName("li")
        var list_categories =[]
        var dict_results = {}
        for(li of lis){
            category=li.textContent
            var is_age_available = REX_AGE.exec(category);
            if(LIST_GENDER.includes(category)){
              dict_results["gender_google"]=category
            }
            else if(is_age_available!=null | category.includes(" Jahre alt")){
              if(category.includes(" Jahre alt")){
                dict_results["age_google"]=category.replace(" – ","-").replace(" Jahre alt"," years old")
              }else{
                dict_results["age_google"]=is_age_available[0]+" years old"
              }
            }
            else{
              list_categories.push(category)
            }
        }
        if (!("gender_google" in dict_results)) {
            dict_results["gender_google"]="no_result"
        }
        if (!("age_google" in dict_results)) {
            dict_results["age_google"]="no_result years old"
        }
        dict_results["categories_google"]=list_categories
        for (key in dict_results){
          localStorage.setItem(key, dict_results[key]);
        }
        send_categories_and_gender_background(dict_results)
        GOOGLE_ERROR=false
      }
      else if(xmlhttp_GOOGLE.readyState === 4){
        GOOGLE_ERROR=true
        chrome.tabs.create({'url':'https://adssettings.google.com/authenticated'})
        GOOGLE_FIRST_CALL=false
      }
    }
    xmlhttp_GOOGLE.send(null);
  }catch(e){
    console.log("ERROR GOOGLE SURVEY")
  }
  //FB
  try{
      var xmlhttp = new XMLHttpRequest();
      var url_request = "https://m.facebook.com/ads/preferences/categories/";
      xmlhttp.open("GET",url_request, true);
      xmlhttp.onreadystatechange = function (e) {
          if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && (!xmlhttp.responseURL.startsWith("https://m.facebook.com/login.php"))){
              var response = xmlhttp.responseText;
              var parser = new DOMParser();
              var htmlDoc = parser.parseFromString(response, 'text/html');
              let div = htmlDoc.querySelectorAll('[data-nt="NT:DECOR"]')
              var elements = [];
              for (index_div=0;index_div<div.length;index_div++){
                var category_fb=div[index_div].textContent
                try{
                  splitter=category_fb.split(/Remove/g)
                  if(splitter.length>1){
                    var category_final =splitter[0]
                    var preferences = new Object();
                    category_final=category_final.replace(",",":")
                    preferences.fbid = "no_result";
                    preferences.name = category_final;
                    preferences.topic = category_final;
                    preferences.id =index_div;
                    preferences.description = "no_result";
                    elements.push((preferences));
                  }
                }catch(e){;}
              }
              //
              var obj = {};
              for ( var i=0, len=elements.length; i < len; i++ )
                  obj[elements[i]['id']] = elements[i];
              //
              elements = new Array();
              for ( var key in obj )
                  elements.push(obj[key]);
              localStorage.setItem("user_preferences",JSON.stringify(elements));
              ///
              FB_ERROR=false
              visiting_popup()
          }

          else if(xmlhttp.readyState === 4 ){
            if(GOOGLE_ERROR==false){
              visiting_popup()
            }
            FB_ERROR=true
            alert("Please loggin into your FB Acccount!")
            FB_FIRST_CALL=false
          }

      };
      xmlhttp.send(null);
  }catch(e){;}//First try, general one


}
/*--------------------------
users id!-------------------
--------------------------*/
function generate_value(){

  var randomPool = new Uint8Array(32);
  crypto.getRandomValues(randomPool);
  var hex = '';
  for (var i = 0; i < randomPool.length; ++i) {
      hex += randomPool[i].toString(16);
  }
  return hex
}
function getRandomToken() {
    // E.g. 8 * 32 = 256 bits token
    hex_value=generate_value()
    return hex_value;
}

function save_user(user_id){
    try{

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function(oEvent) {
            if(xhr.readyState==4){
              if(this.status === 200){;}else{;}
            }
        }
        xhr.open('POST', URL_DB+"/api/v1.0/save_user");
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.send(JSON.stringify(user_id));

    }catch(e){
      console.log('Error sending NEW USER ID information to the DB ', e);
    }
}

chrome.storage.sync.get('userid', function(items) {
    var userid = items.userid;
    if (userid) {
        useToken(userid);
        localStorage.setItem("user_id", userid);
    } else {
        userid = getRandomToken();
        //exists= exists_user(userid)
        chrome.storage.sync.set({userid: userid}, function() {
            useToken(userid);
        });
        //save value in the db
        save_user(userid)
        localStorage.setItem("user_id", userid);
    }
    function useToken(userid) {
      USER_ID_VALUE=userid
    }
});
//GET
chrome.storage.sync.get('agree', function(items) {
    var agree_value_sync=items.agree;
    if(agree_value_sync){
      useAgree("agree")
      localStorage.setItem("agree", AGREE_VALUE);
    }
    function useAgree(agree) {
      AGREE_VALUE=agree
    }
});
//Tems of service send data

function save_terms_of_service(status){
  //if(AGREE_VALUE=="agree"){
    var terms_of_service={
      user_id:localStorage.getItem("user_id"),
      status:status
    }
    try{

      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(oEvent) {
          if(xhr.readyState==4){
            if(this.status === 200){;}else{;}
          }
      }
      xhr.open('POST', URL_DB+"/api/v1.0/terms_of_service");
      xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(terms_of_service));
    }catch(e){
      console.log('Error sending Traffic information to the DB ', e);
    }
  //}
}
//FB SEND INFO DB
function sendUserPreferencesFB_DB(){
  //Get Categories
  try{
    var categories_fb={
      user_id:localStorage.getItem("user_id"),
      user_preferences:JSON.parse(localStorage.getItem("user_preferences"))
    }
  }catch(error_send_categories_fb_db){console.log(error_send_categories_fb_db)}
  //Send categories
  try{
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(oEvent) {
        if(xhr.readyState==4){
          if(this.status === 200){;}else{;}
        }
    }//https
    if(localStorage.getItem("user_preferences")!=null){
      xhr.open('POST', URL_DB+"/api/v1.0/categoriesBackgroundFB");
      xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(categories_fb));
    }
  }catch(e){
    console.log('Error sending Categories Background FB to the DB ', e);
  }
}
/*--------------------------------------------*/
/**Section Recieves the ads collected on a website.**/
/*--------------------------------------------*/
//Function that recieves the results  (Ads)
chrome.runtime.onMessage.addListener(
  function (request, sender, response) {
    switch (request.type) {
      case 'resultsAds':
        try {
          send_ads_database(request);
          break;
      }catch(e){console.log('Error on resultsAds request - Message: ' + e.message);}
      case 'iFrame_in':
        try {
          var tab = tabsArray[sender.tab.id];
          response({url: sender.tab.url})//, timestamp: tab.timestamp});
          tabsArray[sender.tab.id] = tab;
        } catch(e) {
          console.log('Error on iFrame timestamp request - Message: ' + e.message);
        }
        break;
      case 'terms':
          var terms_result=request.message
          try{
            //Case user does not agree
            if(terms_result=="not_agree"){
              AGREE_VALUE="not_agree"
              chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
              var currTab = tabs[0];
              if (currTab) { // Sanity check
                chrome.tabs.update(currTab.id,{url: "terms/user_rejected.html"})
              }
            });
            }
            else{
              chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
              var currTab = tabs[0];
                if (currTab) { // Sanity check
                  chrome.tabs.remove(currTab.id)
                }
            });
              save_terms_of_service("agree")
              chrome.storage.sync.set({agree: "agree"}, function() {
                  AGREE_VALUE="agree"
              });
              ///When user sets that is agree, show the survey
              get_categories_for_survey()

            }

          }catch(e){
            console.log("ERROR AGREE")
          }
          break
      case 'age_consent':
          var age_consent=request.message
          try{
            //Case user does not agree
            if(age_consent=="minor"){
              //chrome.tabs.update({ url: "terms/user_minor.html"});
              chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
              var currTab = tabs[0];
              if (currTab) { // Sanity check
                chrome.tabs.update(currTab.id,{url: "age_verification/user_minor_result.html"})
              }
            });
            }
            else{
              chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
              var currTab = tabs[0];
              if (currTab) { // Sanity check
                chrome.tabs.update(currTab.id,{url: "terms/terms.html"})
              }
            });
            }

          }catch(e){
            console.log(e)
            console.log("ERROR AGREE")
          }
          break
    }
    //fb
    switch (request.message) {
      case "firstDOM":
        getUserPreferences();
        sendUserPreferencesFB_DB();
        break;
      case "getWAST":
          chrome.tabs.create({url: request.url_request, active: false }, tab =>{
              chrome.tabs.executeScript(tab.id, {file: 'facebook/inject/parseWAST.js'});
              setTimeout(function(){
                  chrome.tabs.remove(tab.id);
              },5000);
          });
        break
      case "parseWAST":
        if(localStorage.getItem("reasons")){
            var reasons = new Map(JSON.parse(localStorage.getItem("reasons")));
        }else{
            var reasons = new Map();
        }
        send_reasons_db()
        var array_info = request.source;
        var ad_id = array_info[0];
        ad_id = ad_id.substring(ad_id.indexOf('"ad_id":"')+9,ad_id.indexOf('"}'));
        if(!reasons.has(ad_id))
            reasons.set(ad_id,array_info);
        localStorage.setItem("reasons",JSON.stringify([...reasons]));
        if(array_info.length>1){ //Significa que estoy desbloqueado
            /*Aqui intento coger las que me bloquearon*/
            if(localStorage.getItem("reasons")){
                var reasons = new Map(JSON.parse(localStorage.getItem("reasons")));
                var maximo = 0;
                for (let [k, v] of reasons) {
                    if(v.length == 1 & maximo < 3){
                        maximo = maximo+1;
                        chrome.tabs.create({url: v[0], active: false }, tab =>{
                            chrome.tabs.executeScript(tab.id, {file: 'inject/parseWAST.js'});
                            setTimeout(function(){
                                chrome.tabs.remove(tab.id);
                            },5000);
                        });
                    }
                }
            }
        }
        send_reasons_db();
        break;
      //DEFAULT
      default:
        break;
    }
  })

function send_reasons_db(){

  //saved
  reasons_saved=localStorage.getItem("reasons_saved")
  reasons_analyzed=[]
  if(reasons_saved!=null){
    reasons_saved=reasons_saved.split(",")
    for (key in reasons_saved){
      reasons_analyzed.push(reasons_saved[key])
    }
  }
  //reasons

  if(localStorage.getItem("reasons")){
      var reasons = new Map(JSON.parse(localStorage.getItem("reasons")));
      for (let [id, value] of reasons) {
        if(!reasons_analyzed.includes(id)){
          reasons_analyzed.push(id)
          c_reasons=2
          reasons=""
          while(c_reasons<value.length){
            if(c_reasons==2){
              reasons=value[c_reasons]
            }
            else{
              reasons=reasons+","+value[c_reasons]
            }
            c_reasons++;
          }
          ads_save={
            user_id:USER_ID_VALUE,
            ad_id:id,
            url_ad:value[0],
            img_ad:value[1],
            reasons:reasons
          }
          try{
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function(oEvent) {
                if(xhr.readyState==4){
                  if(this.status === 200){;}else{;}
                }
            }
            xhr.open('POST', URL_DB+"/api/v1.0/reasons_FB");
                        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            xhr.send(JSON.stringify(ads_save));
          }catch(e){
            console.log('Error sending Traffic information to the DB ', e);
          }
        }
      }
    }
    localStorage.setItem("reasons_saved",reasons_analyzed);
}
send_reasons_db()

function send_ads_database(ads){
  if(AGREE_VALUE=="agree"){
    if(!ads.ads.hasOwnProperty("explanation")){
      ads.ads.explanation="no_result"
    }
    if(!ads.ads.hasOwnProperty("type_ad")){
      ads.ads.type_ad="no_result"
    }
    if(!ads.ads.hasOwnProperty("src_ad")){
      ads.ads.src_ad="no_result"
    }
    var data_to_send={
      user_id:USER_ID_VALUE,
      explanation:ads.ads.explanation,
      type_ad:ads.ads.type_ad,
      landing_page:ads.ads.landing_page,
      src_ad:ads.ads.src_ad,
      current_url:ads.ads.current_url
    }
    try{
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(oEvent) {
          if(xhr.readyState==4){
            if(this.status === 200){;}else{;}
          }
      }
      xhr.open('POST', URL_DB+"/api/v1.0/ads");
          xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(data_to_send));
    }catch(e){
      console.log('Error sending ads information to the DB ', e);
    }
  }
}

/**********************************/
/*Section Collect the preferences of the user in background*/
/**********************************/
chrome.browserAction.onClicked.addListener(function(tab) {
  getUserPreferences_survey();//fb
  sendUserPreferencesFB_DB()//FB
  get_user_preferences_google();//Google

});
//Function that collects the preferences and opens the survey
function get_user_preferences_google(){
  ERROR_NOT_LOGGING=false
  FIRST_CHECK=true
  try{
      var url_request = "https://adssettings.google.com/authenticated";
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.open("GET",url_request, true);
      xmlhttp.onreadystatechange = function (e) {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && (xmlhttp.responseURL.startsWith("https://adssettings.google.com/authenticated") )){
          var response = xmlhttp.responseText;
          var parser = new DOMParser();
          var htmlDoc = parser.parseFromString(response, 'text/html');
          let div = htmlDoc.querySelector("#yDmH0d > c-wiz > c-wiz > div > c-wiz:nth-child(4) > div")
          let lis = div.getElementsByTagName("li")
          var list_categories =[]
          var dict_results = {}
          for(li of lis){
              category=li.textContent
              var is_age_available = REX_AGE.exec(category);
              if(LIST_GENDER.includes(category)){
                dict_results["gender_google"]=category
              }
              else if(is_age_available!=null | category.includes(" Jahre alt")){
                if(category.includes(" Jahre alt")){
                  dict_results["age_google"]=category.replace(" – ","-").replace(" Jahre alt"," years old")
                }else{
                  dict_results["age_google"]=is_age_available[0]+" years old"
                }
              }
              else{
                list_categories.push(category)
              }
          }
          if (!("gender_google" in dict_results)) {
              dict_results["gender_google"]="no_result"
          }
          if (!("age_google" in dict_results)) {
              dict_results["age_google"]="no_result years old"
          }
          dict_results["categories_google"]=list_categories
          for (key in dict_results){
            localStorage.setItem(key, dict_results[key]);
          }
          send_categories_and_gender_background(dict_results)
          ERROR_NOT_LOGGING=false
          visiting_popup();
        }
        else if(xmlhttp.readyState === 4){

          ERROR_NOT_LOGGING=true
          alert("Please, login into your Google Account!")
          chrome.tabs.create({'url':'https://adssettings.google.com/authenticated'})
          FIRST_CHECK=false
          if(ERROR_lOGGING_FB_GENERAL==false){
            visiting_popup()
          }
        }
      }
      xmlhttp.send(null);
    }catch(e){
    }
}
//Function to open the survey
function visiting_popup(){
  chrome.tabs.create({'url':'survey/popup.html'})
}

//****************************************************************************//
//*Functions to retreive the categories in background and send them to the DB*//
//****************************************************************************//
execute_fb_categories_bg()
function execute_fb_categories_bg() {
  getUserPreferences();
  sendUserPreferencesFB_DB();
  setTimeout(function () { execute_fb_categories_bg(); }, CATEGORIES_BACKGROUND_TIMER_FB);
}

execute_google_categories_bg()
function execute_google_categories_bg() {
  get_categories_google()
  setTimeout(function () { execute_google_categories_bg(); }, CATEGORIES_BACKGROUND_TIMER_GOOGLE);
}
function get_categories_google(){
  ERROR_NOT_LOGGING=false
  FIRST_CHECK=true
  try{
      var url_request = "https://adssettings.google.com/authenticated";
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.open("GET",url_request, true);
      xmlhttp.onreadystatechange = function (e) {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && (xmlhttp.responseURL.startsWith("https://adssettings.google.com/authenticated"))){
          //Response
          var response = xmlhttp.responseText;
          //Parse the HTML
          var parser = new DOMParser();
          var htmlDoc = parser.parseFromString(response, 'text/html');
          let div = htmlDoc.querySelector("#yDmH0d > c-wiz > c-wiz > div > c-wiz:nth-child(4) > div")
          let lis = div.getElementsByTagName("li")
          var list_categories =[]
          var dict_results={};
          for(li of lis){
              category=li.textContent
              var is_age_available = REX_AGE.exec(category);
              if(LIST_GENDER.includes(category)){
                dict_results["gender_google"]=category
              }
              else if(is_age_available!=null | category.includes(" Jahre alt")){
                if(category.includes(" Jahre alt")){
                  dict_results["age_google"]=category.replace(" – ","-").replace(" Jahre alt"," years old")
                }else{
                  dict_results["age_google"]=is_age_available[0]+" years old"
                }
              }
              else{
                //Parsear las categorias para que no contengan si Jahre alt"mbolos especiales
                list_categories.push(category)
              }
          }
          if (!("gender_google" in dict_results)) {
              dict_results["gender_google"]="no_result"
          }
          if (!("age_google" in dict_results)) {
              dict_results["age_google"]="no_result years old"
          }
          dict_results["categories_google"]=list_categories
          //*Send the information to the DB*//
          send_categories_and_gender_background(dict_results)
          ERROR_NOT_LOGGING=false
        }
        else if(xmlhttp.readyState === 4){
          ERROR_NOT_LOGGING=true
        }
        if(ERROR_NOT_LOGGING && FIRST_CHECK) {
          alert("Please loggin into your Google Acccount!")
          chrome.tabs.create({'url':'https://adssettings.google.com/authenticated'})
          FIRST_CHECK=false
        }
      }
      xmlhttp.send(null);
    }catch(e){
      console.log("Internal error...",e)

    }
}
function clean_categories(category){
  const acentos_y_especiales = {'á':'a','é':'e','í':'i','ó':'o','ú':'u','Á':'A','É':'E','Í':'I','Ó':'O','Ú':'U',"ñ":"n"};
  var category_clean=category.split('').map( letra => acentos[letra] || letra).join('').toString();


}
//Function send categories in backgrond to the DB
function send_categories_and_gender_background(data){
  //cambiar
  if(AGREE_VALUE=="agree"){
    data_to_send_categories={
      user_id:USER_ID_VALUE,
      categories:data.categories_google
    }
    data_to_send_demographics={
      user_id:USER_ID_VALUE,
      gender:data.gender_google,
      age:data.age_google,
    }
    //Send categories
    try{
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(oEvent) {
          if(xhr.readyState==4){
            if(this.status === 200){;}else{;}
          }
      }//https
      xhr.open('POST', URL_DB+"/api/v1.0/categoriesBackground");
          xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(data_to_send_categories));
    }catch(e){
      console.log('Error sending Categories Background information to the DB ', e);
    }
    //send demographic
    try{
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(oEvent) {
          if(xhr.readyState==4){
            if(this.status === 200){;}else{;}
          }
      }//https
      xhr.open('POST', URL_DB+"/api/v1.0/demographicBackground");
      xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(data_to_send_demographics));
    }catch(e){
      console.log('Error sending Demographic Background information to the DB ', e);
    }
  }
}
/*******************************/
/**Section Get the url of every tab**/
/*******************************/
//This function update the tab_ids_url object when there is an update on a Tab
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (!tab_ids_urls.hasOwnProperty(tab.id)) {
      var url=new URL(tab.url)
      var origin = url.origin
      var href_tab = url.href
      tab_ids_urls[tab.id]={
        url_visited:href_tab
      }
      if((!origin.startsWith("edge://")) &&(!origin.startsWith("chrome://")) && (!origin.startsWith("chrome-extension")) && (!origin.startsWith("https://verea.networks.imdea.org")) &&  (!origin.startsWith("https://facebook")) && (!origin.startsWith("https://www.facebook"))  && (!origin.startsWith("https://m.facebook")) ){
        send_url_visited_db(origin)
      }
    }else {
      var url=new URL(tab.url)
      var origin = url.origin
      var href_tab = url.href
      previous_origin=tab_ids_urls[tab.id].url_visited
      if(previous_origin!=href_tab){
        tab_ids_urls[tab.id]={
          url_visited:href_tab
        }
        if((!origin.startsWith("edge://")) &&(!origin.startsWith("chrome://") ) && (!origin.startsWith("chrome-extension")) && (!origin.startsWith("https://verea.networks.imdea.org")) &&  (!origin.startsWith("https://facebook")) && (!origin.startsWith("https://www.facebook")) && (!origin.startsWith("https://m.facebook") )  ){
          send_url_visited_db(origin)
        }
      }
    }
  });
//This function send to the DB the websites that user's visit
function send_url_visited_db(url_visited){
  if(AGREE_VALUE=="agree"){
    var data_to_send={
      user_id:USER_ID_VALUE,
      url_visited:url_visited
    }


    try{
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function(oEvent) {
          if(xhr.readyState==4){
            if(this.status === 200){;}else{;}
          }
      }
      xhr.open('POST', URL_DB+"/api/v1.0/urls_visited");
      xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhr.send(JSON.stringify(data_to_send));
    }catch(e){
      console.log('Error sending website visited information to the DB ', e);
    }
  }
}
  //This function update the tab_ids_url object when there is a new Tab is created
chrome.tabs.onCreated.addListener(function(tab) {
    if (!tab_ids_urls.hasOwnProperty(tab.id)) {
      tab_ids_urls[tab.id]={
        url_visited:tab.url
        }
    }else {
        previous_url=tab_ids_urls[tab.id].url_visited
        if(previous_url!=tab.url){
          tab_ids_urls[tab.id]={
            url_visited:tab.url
          }
        }
      }
  })
//Not sepecify what this tab does
function getCurrentTabUrl(callback) {
    chrome.tabs.query(
      {active:true, currentWindow:true},
      function(tabs){
        CURRENT_TAB_URL=tabs[0].url
        chrome.runtime.lastError;try{callback(tabs[0].url);}catch (error){}}
      );}
/***********************************/
/**Auxiliar Functions**/
/***********************************/
//Store the ip of the service (remote service)
var updateWebRequestHeaders = function (res) {
  var tabId = res.tabId;
  var requestId = res.requestId;
  webRequestsMap[tabId][requestId]["ip"] = res.ip;
};
