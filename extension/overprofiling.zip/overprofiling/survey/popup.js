
var table = select("#categories");
USER_ID=localStorage.getItem("user_id")
GOOGLE_INFORMATION=localStorage.getItem("google_adssettings")
NUMBER_CATEGORIES_GOOGLE=25
NUMBER_CATEGORIES_FB=50

try{
  age=localStorage.getItem("age_google")
  //age=GOOGLE_INFORMATION["age"]
  var row = table.insertRow(0);
  row.innerHTML='<tr><div class="radio-toolbar"><div class="div_text"><p class="text_p">'+age+'</p></div><input type="radio" id="'+age+'1" name="'+age+"user_id_value"+USER_ID+'" value="Correcta" ><label for="'+age+'1">Correct</label><input type="radio" id="'+age+'2" name="'+age+"user_id_value"+USER_ID+'" value="Incorrecta" ><label for="'+age+'2">Incorrect</label></div></tr>'
}catch(e){;}

try{
  gender=localStorage.getItem("gender_google")
  //gender=GOOGLE_INFORMATION["gender"]
  var row = table.insertRow(0);
  row.innerHTML='<tr><div class="radio-toolbar"><div class="div_text"><p class="text_p">'+gender+'</p></div><input type="radio" id="'+gender+'1" name="'+gender+"user_id_value"+USER_ID+'" value="Correcta" ><label for="'+gender+'1">Correct</label><input type="radio" id="'+gender+'2" name="'+gender+"user_id_value"+USER_ID+'" value="Incorrecta" ><label for="'+gender+'2">Incorrect</label></div></tr>'
}catch(e){;}

//Categories Google
try{
  categories=localStorage.getItem("categories_google")
  categories_analyzed_to_save=[]
  analyzed=localStorage.getItem("categories_analyzed")
  if(analyzed!=null){
    analyzed=analyzed.split(",")
    for( key in analyzed){
      console.log("KEY ",analyzed[key],key)
      categories_analyzed_to_save.push(analyzed[key])
    }
  }
  list_categories=categories.split(",");
  list_categories=shuffle(list_categories)
  counter_google_categories=0
  for (key in list_categories){
    category=list_categories[key]
    if(counter_google_categories<NUMBER_CATEGORIES_GOOGLE ){
      if(!categories_analyzed_to_save.includes(category)){
          var row = table.insertRow(-1);
          //row.innerHTML='<tr><div class="radio-toolbar"><div class="div_text"><p class="text_p">'+category+'</p></div><input type="radio" id="'+category+'1" name="'+category+"user_id_value"+USER_ID+'" value="Correcta" ><label for="'+category+'1">Correct</label><input type="radio" id="'+category+'2" name="'+category+"user_id_value"+USER_ID+'" value="Incorrecta" ><label for="'+category+'2">Incorrect</label><input type="radio" id="'+category+'3" name="'+category+"user_id_value"+USER_ID+'" value="Contraria" ><label for="'+category+'3">Opposite</label></div></tr>'
          row.innerHTML='<tr><div class="radio-toolbar">  <div class="div_text"><p class="text_p">'+category+'</p></div> <input type="radio" id="'+category+'1" name="'+category+"user_id_value"+USER_ID+'" value="1" ><label for="'+category+'1">1</label>  <input type="radio" id="'+category+'2" name="'+category+"user_id_value"+USER_ID+'" value="2" ><label for="'+category+'2">2</label>  <input type="radio" id="'+category+'3" name="'+category+"user_id_value"+USER_ID+'" value="3" ><label for="'+category+'3">3</label>  <input type="radio" id="'+category+'4" name="'+category+"user_id_value"+USER_ID+'" value="4" ><label for="'+category+'4">4</label>  <input type="radio" id="'+category+'5" name="'+category+"user_id_value"+USER_ID+'" value="5" ><label for="'+category+'5">5</label></div></tr>'
          categories_analyzed_to_save.push(category)
          counter_google_categories=counter_google_categories+1;
        }
      }else{break; }
    }
    console.log("GUARDAR")
    console.log(categories_analyzed_to_save)
    localStorage.setItem("categories_analyzed",categories_analyzed_to_save)
}catch(e){console.log("Error",e);

}
//Categories facebook
try{
  analyzed=localStorage.getItem("categories_analyzed")
  if(analyzed!=null){
    analyzed=analyzed.split(",")
    for( key in analyzed){
      categories_analyzed_to_save.push(analyzed[key])
    }
  }
  categories=JSON.parse(localStorage.getItem("user_preferences"))
  list_categories=[]
  for ( index in categories){
    category=categories[index]["name"]
    list_categories.push(category)
  }
  counter_fb_categories=0
  list_categories=shuffle(list_categories)
  for (index in list_categories){
    if(counter_fb_categories<NUMBER_CATEGORIES_FB ){
      category=list_categories[index]
      if(!categories_analyzed_to_save.includes(category)){
          var row = table.insertRow(-1);
          row.innerHTML='<tr><div class="radio-toolbar"><div class="div_text"><p class="text_p">'+category+'</p></div><input type="radio" id="'+category+'1" name="'+category+"user_id_value"+USER_ID+'" value="1" ><label for="'+category+'1">1</label><input type="radio" id="'+category+'2" name="'+category+"user_id_value"+USER_ID+'" value="2" ><label for="'+category+'2">2</label><input type="radio" id="'+category+'3" name="'+category+"user_id_value"+USER_ID+'" value="3" ><label for="'+category+'3">3</label><input type="radio" id="'+category+'4" name="'+category+"user_id_value"+USER_ID+'" value="4" ><label for="'+category+'4">4</label><input type="radio" id="'+category+'5" name="'+category+"user_id_value"+USER_ID+'" value="5" ><label for="'+category+'5">5</label></div></tr>'
          console.log(category)
          counter_fb_categories=counter_fb_categories+1;
          categories_analyzed_to_save.push(category)
        }
      }else{break; }
  }
  localStorage.setItem("categories_analyzed",categories_analyzed_to_save)
}catch(e){console.log("Error",e);

}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
}

function select(selector) {
  console.log("select")
  return document.querySelector(selector);
}
