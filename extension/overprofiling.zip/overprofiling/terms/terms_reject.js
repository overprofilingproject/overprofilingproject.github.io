document.getElementById("submit_button_not_agree").onclick = function () {
  localStorage.setItem("agree","not_agree")
  chrome.runtime.sendMessage({type: 'terms', message:"not_agree" });

};
