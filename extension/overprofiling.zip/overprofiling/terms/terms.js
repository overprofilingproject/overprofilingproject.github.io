document.getElementById("submit_button").onclick = function () {
  localStorage.setItem("agree","agree")
  chrome.runtime.sendMessage({type: 'terms', message:"agree" });

};
