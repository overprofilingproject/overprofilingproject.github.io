/* This method allows parsing the preferences */
// This and the following method include the preferences inside the localStorage of the extension
function parseResponsePreferences(response){
    base_end = 'x3C/div>';
    var init_cat_html = getMatchIndices(/data-sigil="category-selector">/g, response);
    var finish_cat_html = getMatchIndices(/\<\/html\>/g, response);

    var elements = [];
    for(var i=0;i<init_cat_html.length;i++){
        var r = /\\u([\d\w]{4})/gi;
        var html_category = response.substring(init_cat_html[i]+31,finish_cat_html[i]);
        var topic = html_category.substring(0, html_category.length);
        topic = topic.substring(0,topic.indexOf('<'));
        var indexes = getMatchIndices(/causalSigil:"interest-chevron-/g, html_category);
        for(var ii=0; ii<indexes.length; ii++){
            var r = /\\u([\d\w]{4})/gi;
            var aux = html_category.substring(indexes[ii]+30, html_category.length);
            aux = aux.substring(0,aux.indexOf('data-sigil='));
            aux = aux.replace(r, function (match, grp) {return String.fromCharCode(parseInt(grp, 16));});
            aux = unescape(aux);
            var name = aux.substring(aux.indexOf('x3Cdiv>')+7, aux.indexOf(base_end)-1); //Getting preference name
            var fbid = aux.substring(0, aux.indexOf('"')); //Getting preference fbid
            var description = aux.substring(aux.indexOf("_28dc")+8, aux.length); //Getting the description
            description = description.substring(0, description.indexOf(base_end)-1);
            if(topic.includes("div class")){
                fbid = name;
                topic = "Demographics";
            }
            //We save the preferences and each value in a JSON
            var preferences = new Object();
            preferences.fbid = fbid;
            preferences.name = name;
            preferences.topic = topic;
            preferences.id = fbid;
            preferences.description = description;
            elements.push((preferences));
        }
    }
    var obj = {};

    for ( var i=0, len=elements.length; i < len; i++ )
        obj[elements[i]['id']] = elements[i];

    elements = new Array();
    for ( var key in obj )
        elements.push(obj[key]);
    localStorage.setItem("user_preferences",JSON.stringify(elements));
}

/* Function for getting the preferences assigned to the user */
//This method works together with the previous one, the one below runs before getting the preference categories
//and the one above gets each particular preference and stores it under 'user_preferences' in localStorage
function getUserPreferences(){
    var xmlhttp = new XMLHttpRequest();
    var url_request = "https://m.facebook.com/ads/preferences/categories/";
    xmlhttp.open("GET",url_request, true);
    console.log("status: ",xmlhttp.status)
    xmlhttp.onreadystatechange = function (e) {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200){
            var response = xmlhttp.responseText;
            console.log("--------------TEST--------------")
            console.log(response)
            console.log("--------------------------------")
            var init_search_carousel = "ads/preferences/categories/?category_name=";
            var indexes = getMatchIndices(/ads\/preferences\/categories\/\?category_name=/g, response); //We find all the categories

            var categories = [];
            for(var index=1; index<indexes.length; index++){
                var cat=response.substring(indexes[index]+init_search_carousel.length,response.length);
                cat = cat.substring(0,cat.indexOf('\\\"'));
                categories.push(cat);
            }
            var url_category = [];
            for(var i=0; i<categories.length; i++){ //We add the URL for that category
                var aux = encodeURI(categories[i]);
                url_category.push("https://m.facebook.com/ads/preferences/categories/?category_name=" + aux + "&locale=en_US");
            }
            var nRequest = [];
            var resp = "";
            var j = 0;
            for (var i=0; i<categories.length; i++){
                (function(i) { //For all the categories we look in the URL
                    nRequest[i] = new XMLHttpRequest();
                    nRequest[i].open("GET", url_category[i], true);
                    nRequest[i].onreadystatechange = function (oEvent) {
                        if (nRequest[i].readyState === 4 && nRequest[i].status === 200) {
                            resp = resp + nRequest[i].responseText;
                            j++;
                            if(j==categories.length) parseResponsePreferences(resp);
                        }
                    };
                    nRequest[i].send(null);
                })(i);
            }
        }
    };
    xmlhttp.send(null);
}

/* Function to get all de indices for a specific string */
function getMatchIndices(regex, str){
   var result = [];
   var match;
   regex = new RegExp(regex);
   while (match = regex.exec(str)) result.push(match.index);
   return result;
}

/* Here all the communication is done */
chrome.runtime.onMessage.addListener(function(request, sender) {
  console.log("RUNTIME")
  console.log("Request message ",request.message)
    if (request.message == 'firstDOM'){
        getUserPreferences();
    }else if (request.message == "getWAST"){
        chrome.tabs.create({url: request.url_request, active: false }, tab =>{
            chrome.tabs.executeScript(tab.id, {file: 'inject/parseWAST.js'});
            setTimeout(function(){
                chrome.tabs.remove(tab.id);
            },5000);
        });
    }else if (request.message == "parseWAST"){
        if(localStorage.getItem("reasons")){
            var reasons = new Map(JSON.parse(localStorage.getItem("reasons")));
        }else{
            var reasons = new Map();
        }
        //Extract the ad_id:
        var array_info = request.source;
        var ad_id = array_info[0];
        ad_id = ad_id.substring(ad_id.indexOf('"ad_id":"')+9,ad_id.indexOf('"}'));
        if(!reasons.has(ad_id))
            reasons.set(ad_id,array_info);
        localStorage.setItem("reasons",JSON.stringify([...reasons]));
        if(array_info.length>1){ //Significa que estoy desbloqueado
            /*Aqui intento coger las que me bloquearon*/
            if(localStorage.getItem("reasons")){
                var reasons = new Map(JSON.parse(localStorage.getItem("reasons")));
                var maximo = 0;
                for (let [k, v] of reasons) {
                    if(v.length == 1 & maximo < 3){
                        maximo = maximo+1;
                        chrome.tabs.create({url: v[0], active: false }, tab =>{
                            chrome.tabs.executeScript(tab.id, {file: 'inject/parseWAST.js'});
                            setTimeout(function(){
                                chrome.tabs.remove(tab.id);
                            },5000);
                        });
                    }
                }
            }
        }
    }
});
