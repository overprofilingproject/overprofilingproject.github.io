/* Injected SCRIPT */
/* Method to get the reasons why I see the ad */
//Once we have opened the website we extract the reasons and send them to the background.js
function DOMCounter(document){
    return_array = [decodeURIComponent(decodeURI(window.location.href))];
    if(document.querySelector("img[style*='fit: cover']"))
        return_array.push(document.querySelector("img[style*='fit: cover']").src);
    else
        return_array.push('no image');
    reasons = document.querySelectorAll("div[aria-label='Detail page']");
    for(var i=0; i<reasons.length; i++)
        return_array.push(reasons[i].textContent);
    console.log("Return value from parseWAST! ",return_array)
    return return_array
}

chrome.runtime.sendMessage({
    message: "parseWAST",
    source: DOMCounter(document)
});
