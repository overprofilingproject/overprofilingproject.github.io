/* Injected SCRIPT */
/* Method that intercepts the connections done by FB and gets the information of AD_id and TOKEN for requesting the reasons */
function interceptData() {
  var xhrOverrideScript = document.createElement('script');
  xhrOverrideScript.type = 'text/javascript';
  xhrOverrideScript.innerHTML = `
  (function() {
    var XHR = XMLHttpRequest.prototype;
    var send = XHR.send;
    var open = XHR.open;
    XHR.open = function(method, url) {
        this.url = url; // the request url
        return open.apply(this, arguments);
    }
    XHR.send = function() {
        this.addEventListener('load', function() {
            if (this.url.includes('api/graphql')) {
              if(this.response.indexOf('ad_id') != -1){
                //console.log('ad!');
                var ad_id = this.response.substring(this.response.indexOf('"ad_id":')+9,this.response.length);
                ad_id = ad_id.substring(ad_id, ad_id.indexOf('"}'));
                var client_token = this.response.substring(this.response.indexOf('"client_token":')+16,this.response.length);
                client_token = client_token.substring(client_token, client_token.indexOf('"}'));
                //console.log(client_token);
                var dataDOMElement = document.createElement('div');
                dataDOMElement.className = '__interceptedData';
                div_ad = document.createElement('div');
                div_tok = document.createElement('div');
                div_ad.id = 'intercepted_adid';
                div_tok.id = 'intercepted_clienttok';
                div_ad.textContent = ad_id;
                div_tok.textContent = client_token;
                dataDOMElement.style.height = 0;
                dataDOMElement.style.overflow = 'hidden';
                dataDOMElement.appendChild(div_ad);
                dataDOMElement.appendChild(div_tok);
                document.body.appendChild(dataDOMElement);
              }
            }

        });
        return send.apply(this, arguments);
    };
  })();
  `
  document.head.prepend(xhrOverrideScript);
}

/* This method checks if the DOM is ready and sends a message to get preferences */
function checkForDOM() {
  if (document.body && document.head && !document.querySelector('[data-testid="royal_login_button"]')) {
    chrome.runtime.sendMessage({message: "firstDOM"});
    interceptData();
  } else {
    requestIdleCallback(checkForDOM);
  }
}
requestIdleCallback(checkForDOM);

/* It checks whether the interception of connections has been activated or not */
function scrapeData() {
    var responseContainingEle = document.getElementsByClassName('__interceptedData');
    if (responseContainingEle) {
        //var response = JSON.parse(responseContainingEle.innerHTML);
    } else {
        requestIdleCallback(scrapeData);
    }
}
requestIdleCallback(scrapeData);

/* This method does the main processing by extracting the ids and tokens and sending them to be analysed */
function DOMCounter(){
  if(!document.querySelector('[data-testid="royal_login_button"]')){
    if(localStorage.getItem("id_eid"))
        var id_eid = new Map(JSON.parse(localStorage.getItem("id_eid")));
      else
        var id_eid = new Map();

    //there are some ads that do not depend on the connections and are preloaded in advance, we check it before
    var preloaded_ads = getElementsByXPath("//script[contains(., 'ad_id')]",document);
    var adids_preloaded = [];
    var tokens_preloaded = [];
    for(var i=0; i<preloaded_ads.length; i++){

      ads_indexes = getMatchIndices(/"ad_id":/g,preloaded_ads[i].textContent);
      for(var l=0; l<ads_indexes.length; l++){
        var preloaded_ad = preloaded_ads[i].textContent.substring(ads_indexes[l]+9,preloaded_ads[i].textContent.length);
        preloaded_ad = preloaded_ad.substring(preloaded_ad,preloaded_ad.indexOf('"'));

        if(!adids_preloaded.includes(preloaded_ad))
          adids_preloaded.push(preloaded_ad);
      }
      token_indexes = getMatchIndices(/"client_token":/g,preloaded_ads[i].textContent);
      for(var l=0; l<token_indexes.length; l++){
        var preloaded_token = preloaded_ads[i].textContent.substring(token_indexes[l]+16,preloaded_ads[i].textContent.length);
        preloaded_token = preloaded_token.substring(preloaded_token,preloaded_token.indexOf('"'));

        if(!tokens_preloaded.includes(preloaded_token))
          tokens_preloaded.push(preloaded_token);
      }
    }
    if(adids_preloaded.length>0)
      adids_preloaded.shift();
    if(tokens_preloaded.length>0)
      tokens_preloaded.shift();
    //for the preloaded ads we request the reasons with the method getWAST

    for(var i=0; i<adids_preloaded.length; i++){
      if(!id_eid.has(adids_preloaded[i])){
        id_eid.set(adids_preloaded[i],tokens_preloaded[i]);
        //in case the ad is new we send it to be analysed
        getWAST(tokens_preloaded[i], adids_preloaded[i]);
      }
    }
    //now we analyse the intercepted ads
    var ads = document.getElementsByClassName('__interceptedData');
    for(var i=0; i<ads.length; i++){
      adid = ads[i].querySelector('[id="intercepted_adid"]');
      adid = adid.textContent;
      clienttok = ads[i].querySelector('[id="intercepted_clienttok"]');
      clienttok = clienttok.textContent;
      if(!id_eid.has(adid)){
        id_eid.set(adid,clienttok);
        //in case the ad is new we send it to be analysed
        getWAST(clienttok, adid);
      }
    }
    //we store everything inside the session storage of the FB tab in order to be able to know if an ad has been already analysed
    localStorage.setItem("id_eid", JSON.stringify([...id_eid]));
  }
  requestIdleCallback(DOMCounter);
}
requestIdleCallback(DOMCounter);

/* This function sends a message to the background which is going to open a tab with the reasons url */
function getWAST(client_token, id){
  try{
	   chrome.runtime.sendMessage({message: "getWAST", ad_id: id, url_request: 'https://m.facebook.com/nt/screen/?params={"client_token":"'+client_token+'","ad_id":"'+id+'"}&path=/ads/waist&_rdr&locale=en_US'});
  }catch(error_getWast_contentScript){console.log("Error error_getWast_contentScript")}
}

/* Complementary function */
function getElementsByXPath(xpath, parent)
{
    let results = [];
    let query = document.evaluate(xpath, parent || document,
        null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    for (let i = 0, length = query.snapshotLength; i < length; ++i) {
        results.push(query.snapshotItem(i));
    }
    return results;
}

/* Function to get all de indices for a specific string */
function getMatchIndices(regex, str){
  var result = [];
  var match;
  regex = new RegExp(regex);
  while (match = regex.exec(str)) result.push(match.index);


  return result;
}
